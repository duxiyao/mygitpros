package org.myframe.https;

public interface HttpsCb {
	void onResponse(String data);
}
